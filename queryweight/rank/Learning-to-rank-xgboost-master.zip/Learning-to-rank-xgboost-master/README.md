# Learning-to-rank-xgboost
Learning-to-Rank (LTR) model using XGBoost 

Here we use XGBoost LTR model to rank relevant documents in terms of search relevancy. Model takes feature inputs in Libsvm format and ranks the right feature set that determines the ranking among documents or records. 
