# semantic-extractor
基于xlnet微调加预训练的中文语义提取器
